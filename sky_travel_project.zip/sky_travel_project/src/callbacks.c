#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"


void
on_recherche_facture_client_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_creation_code_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_recherche_code_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_confirmation_1_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_quitter_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_creeuncompte_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_rejoindreespace_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_rejoindrecathalogue_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_retour_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_connexion_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_inscription_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_espaceagent_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_espaceadmin_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_espaceclient_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_gestionhotel_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_gestionvol_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_gestionreservation_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{

}

