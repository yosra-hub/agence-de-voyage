
void reserver (char ok1[],int N1,int N2 ,int N3);
