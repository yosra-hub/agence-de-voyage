#include <stdio.h>
#include <stdlib.h>
void ameni (int id,char loula[200],char thenia[200])
{
int cd = 0; char i1 [20] ; char i2 [20] ; char i3 [20]; char i4 [20];char i5 [20];char i6 [20];char i7 [20]; char i8 [20]; char i9 [20]; char i10 [20];
FILE*f;
FILE*Ftemp;
f=fopen("/home/achref/Vidéos/skytravel00/src/reservations.txt","r");
Ftemp=fopen("/home/achref/Vidéos/skytravel00/src/hebergementtemp.txt","w");
while(!feof(f))
    {
	cd++;
     fscanf(f,"%s %s %s %s %s %s %s %s %s %s \n",i1,i2,i3,i4,i5,i6,i7,i8,i9,i10);

       if(id!=cd)
         {fprintf(Ftemp,"%s %s %s %s %s %s %s %s %s %s \n",i1,i2,i3,i4,i5,i6,i7,i8,i9,i10);}
	if(id==cd) {
	sprintf(loula,"%s %s %s",i1,i2,i3);sprintf(thenia,"%s %s %s %s %s",i6,i7,i8,i9,i10);
	
    }}



fclose(f);
fclose(Ftemp);
remove("/home/achref/Vidéos/skytravel00/src/reservations.txt");
rename("/home/achref/Vidéos/skytravel00/src/hebergementtemp.txt","/home/achref/Vidéos/skytravel00/src/reservations.txt");

}
