#include <stdio.h>
#include <string.h>
int verif(char nom[], char prenom[]){
FILE*f;
f=fopen("/home/achref/Vidéos/skytravel00/src/clients.txt","r");
char Nom[20]; char Prenom[20];
char role[20]; char s1[20];
char s2[20]; char s3[20];
if(f !=NULL) {
while(fscanf(f,"%s %s %s %s %s %s",s3,Nom,Prenom,role,s1,s2)!=EOF){
 //parcours du fichier;
printf("%s %s %s \n",Nom,Prenom,s1);
if ((strcmp(nom,Nom)==0) && (strcmp(Prenom,prenom)==0))
{if (strcmp(s1,"agent")==0) return 1;
if (strcmp(s1,"client")==0) return 2;}}
} return 0;
}
