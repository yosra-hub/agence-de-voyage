#include <stdio.h>
#include <stdlib.h>
#include <time.h>

////////////////////////////
void cataloguez (char ok1[],int N1,int N2 ,int N3) {
char FINAL [3000];
srand(time(NULL));
int A = rand();
while((A<200)||(A>3000)) {
A=A/10;}
sprintf(FINAL,"%s %d %d %d",ok1,N1,N2,N3);
FILE*f;
f=fopen("/home/achref/Vidéos/skytravel00/src/catalogue.txt","a+"); //ouvrir un fichier en mode ajout
if(f!=NULL) { 
fprintf(f,"%s \n",FINAL);//écriture dans le fichier
}
fclose(f);
f=fopen("/home/achref/Vidéos/skytravel00/src/cataloguecurrent.txt","w"); //ouvrir un fichier en mode ajout
if(f!=NULL) { 
fprintf(f,"%s \n",FINAL);//écriture dans le fichier
}
fclose(f); //fermeture du fichier
///////////////////
}

