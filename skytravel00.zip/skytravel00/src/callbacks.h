#include <gtk/gtk.h>


void
on_recherche_facture_client_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_creation_code_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_recherche_code_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_confirmation_1_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_rejoindreespace_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_rejoindrecathalogue_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_creeuncompte_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_connexion_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_inscription_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_espaceagent_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_espaceadmin_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_espaceclient_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_gestionhotel_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_gestionvol_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_gestionreservation_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_leavecatalogue_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour12_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button10_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button15_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button16_enter                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button24_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button25_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button27_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button28_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button29_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button26_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button30_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button31_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button32_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
