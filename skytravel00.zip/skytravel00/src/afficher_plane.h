#include <gtk/gtk.h>

typedef struct
{

char date [30];
char classe [30];
char ca [30];


}Reservation;
void afficher_plane(GtkWidget *liste,char TXT[]);
