#include <stdio.h>
#include <stdlib.h>
void ajoutplane (int id,char loula[200],char thenia[200])
{
int cd = 0; char i1 [20] ; char i2 [20] ; char i3 [20]; char i4 [20];char i5 [20];char i6 [20];
FILE*f;
FILE*Ftemp;
f=fopen("/Desktop/skytravel00/skytravel00/src/catalogue.txt","r");
Ftemp=fopen("/Desktop/skytravel00/skytravel00/src/hebergementtemp.txt","w");//pas disponible
while(!feof(f))
    {
	cd++;
     fscanf(f,"%s %s %s %s %s %s \n",i1,i2,i3,i4,i5,i6);

       if(id!=cd)
         {fprintf(Ftemp,"%s %s %s %s %s %s \n",i1,i2,i3,i4,i5,i6);}
	if(id==cd) {
	sprintf(loula,"%s %s",i1,i2);sprintf(thenia,"%s %s %s",i4,i5,i6);
	
    }}



fclose(f);
fclose(Ftemp);
remove("/Desktop/skytravel00/skytravel00/src/catalogue.txt");//supprision des reservation a partir du catalogue
rename("/Desktop/skytravel00/skytravel00/src/hebergementtemp.txt","/Desktop/skytravel00/skytravel00/src/catalogue.txt");

}
